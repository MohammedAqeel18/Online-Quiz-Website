# PROJECT-1
While students are bored of attempting quizzes and the apathy they have  towards them inspired us to come up with an interesting solution. The  young minds always look for entertainment around them along with  exploring knowledgeable stuff. So, we came up with the idea of giving both  knowledge and entertainment together.
